package com.lidroid.xutils.cache;

/**
 * Author: wyouflf
 * Date: 14-5-16
 * Time: 上午11:25
 */
public interface FileNameGenerator {
    public String generate(String key);
}
