package com.lib.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.text.TextUtils;

/**
 * 日期共同类
 * 
 * @author Jun.Wang
 */
public class DateFormats {

	/**
	 * 日期格式模板1 ，格式“MM月dd日”
	 */
	public static final String DATE_FORMAT_1 = "MM月dd日";
	/**
	 * 日期格式模板2 ，格式"yyyy年MM月dd日 HH时mm分ss秒"
	 */
	public static final String DATE_FORMAT_2 = "yyyy年MM月dd日 HH时mm分ss秒";
	/**
	 * 日期格式模板3 ，格式"yyyy年MM月dd日"
	 */
	public static final String DATE_FORMAT_3 = "yyyy年MM月dd日";
	/**
	 * 日期格式模板4，格式"yyyy-MM-dd"
	 */
	public static final String DATE_FORMAT_4 = "yyyy-MM-dd";
	/**
	 * 日期格式模板5 ，格式"yyyy年MM月dd日 HH时mm分ss秒SSS毫秒"
	 */
	public static final String DATE_FORMAT_5 = "yyyy年MM月dd日 HH时mm分ss秒SSS毫秒";
	/**
	 * 日期格式模板6 ，格式"HH:mm"
	 */
	public static final String DATE_FORMAT_6 = "HH:mm";

	/**
	 * 获取格式化的日期
	 * 
	 * @param time
	 *            ： 需要格式化的时间，long类型时间戳
	 * @param formatStr
	 *            ： 格式模板
	 */
	public static String getFormatDate(long time, String formatStr) {
		SimpleDateFormat sdf = new SimpleDateFormat(formatStr);
		return sdf.format(new Date(time));
	}

	/**
	 * 格式化显示时间长度
	 * 
	 * @param timeLen
	 *            : 时间长度，单位（秒）
	 * @param isFillSigle
	 *            : 是否使用0填充不满2位的位置
	 * @return 如 1245小时，显示为"20:45"
	 */
	public static String getFormatTimeLen(int timeLen, boolean isFillSigle) {

		// 时
		int hour = timeLen / 3600;
		// 分
		int min = (timeLen - hour * 3600) / 60;
		// 秒
		int sec = timeLen - hour * 3600 - min * 60;

		//
		String strHour = "", strMin = "", strSec = "";

		//
		if (hour > 0) {
			strHour = String.valueOf(hour);
			if (hour < 10 && isFillSigle) {
				strHour = ("0" + strHour);
			}
		}

		if (min > 0) {
			strMin = String.valueOf(min);
			if (min < 10 && isFillSigle) {
				strMin = ("0" + strMin);
			}
		} else {
			strMin = "00";
		}

		if (sec > 0) {
			strSec = String.valueOf(sec);
			if (sec < 10 && isFillSigle) {
				strSec = ("0" + strSec);
			}
		} else {
			strSec = "00";
		}

		//
		StringBuffer sbFormat = new StringBuffer("");
		if (!TextUtils.isEmpty(strHour)) {
			sbFormat.append(strHour + ":");
		}

		sbFormat.append(strMin + ":");
		sbFormat.append(strSec);

		return sbFormat.toString();
	}

	/**
	 * Check if two time is at the same day.
	 */
	public static boolean isSameDay(long time1, long time2) {
		String strFormat1 = DateFormats.getFormatDate(time1, DateFormats.DATE_FORMAT_3);
		String strFormat2 = DateFormats.getFormatDate(time2, DateFormats.DATE_FORMAT_3);

		return strFormat1.equals(strFormat2);
	}

	public static String getFormatHHmmss(long timeLen) {
		long hour = timeLen / (1000 * 3600);
		long min = (timeLen - hour * 3600 * 1000) / (1000 * 60);
		long sec = (timeLen - hour * 3600 * 1000 - min * 60 * 1000) / 1000;

		String strHour = String.valueOf(hour);
		if (hour == 0) {
			strHour = "";
		} else if (hour < 10) {
			strHour = "0" + hour;
		}

		String strMin = String.valueOf(min);
		if (min < 10) {
			strMin = "0" + min;
		}

		String strSec = String.valueOf(sec);
		if (sec < 10) {
			strSec = "0" + sec;
		}

		if ("".equals(strHour)) {
			return strMin + ":" + strSec;
		}

		return strHour + ":" + strMin + ":" + strSec;
	}
}
