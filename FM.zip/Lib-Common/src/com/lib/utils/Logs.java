package com.lib.utils;

import android.util.Log;

import com.lib.BuildConfig;

/**
 * 日志输出共同类
 * 
 * @author Jun.Wang
 */
public class Logs {
	/**
	 * 是否开启Log
	 */
	public static boolean PRINT_LOG = true;

	/**
	 * Default Log Tag
	 */
	private static String DEFAULT_TAG = "callback";

	/**
	 * Auto set debug mode
	 */
	static {
		try {
			PRINT_LOG = BuildConfig.DEBUG;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * i
	 */
	public static void i(String msg) {
		i(DEFAULT_TAG, msg);
	}

	public static void i(String tag, String msg) {

		if (PRINT_LOG) {
			Log.i(tag, msg);
		}
	}

	public static void i(String tag, String msg, Throwable tr) {

		if (PRINT_LOG) {
			Log.i(tag, msg, tr);
		}
	}

	/**
	 * e
	 */
	public static void e(String msg) {
		e(DEFAULT_TAG, msg);
	}

	public static void e(String tag, String msg) {

		if (PRINT_LOG) {
			Log.e(tag, msg);
		}
	}

	public static void e(String tag, String msg, Throwable tr) {

		if (PRINT_LOG) {
			Log.e(tag, msg, tr);
		}
	}

	/**
	 * d
	 */
	public static void d(String msg) {
		d(DEFAULT_TAG, msg);
	}

	public static void d(String tag, String msg) {

		if (PRINT_LOG) {
			Log.d(tag, msg);
		}
	}

	public static void d(String tag, String msg, Throwable tr) {

		if (PRINT_LOG) {
			Log.d(tag, msg, tr);
		}
	}

	/**
	 * w
	 */
	public static void w(String msg) {
		w(DEFAULT_TAG, msg);
	}

	public static void w(String tag, String msg) {

		if (PRINT_LOG) {
			Log.w(tag, msg);
		}
	}

	public static void w(String tag, String msg, Throwable tr) {

		if (PRINT_LOG) {
			Log.w(tag, msg, tr);
		}
	}

	/**
	 * v
	 */
	public static void v(String msg) {
		v(DEFAULT_TAG, msg);
	}

	public static void v(String tag, String msg) {

		if (PRINT_LOG) {
			Log.v(tag, msg);
		}
	}

	public static void v(String tag, String msg, Throwable tr) {

		if (PRINT_LOG) {
			Log.v(tag, msg, tr);
		}
	}
}
