package com.lib.utils;

import java.text.DecimalFormat;

/**
 * 数字共同类
 * 
 * @author Jun.Wang
 */
public class DigitUtils {

	// 格式："0.0"
	public static final String FORMAT_2 = "0.0";
	// 格式："0.0B"
	public static final String FORMAT_4 = "0.0B";
	// 格式："0.0KB"
	public static final String FORMAT_5 = "0.0KB";
	// 格式："0.0M"
	public static final String FORMAT_1 = "0.0MB";
	// 格式："0.0GB"
	public static final String FORMAT_3 = "0.0GB";
	// 格式："0.0TB"
	public static final String FORMAT_6 = "0.0TB";

	/**
	 * 数字格式化字符串
	 */
	public static String getFormatDigit(double num, String formatStr) {

		DecimalFormat df = new DecimalFormat();
		df.applyPattern(formatStr);

		return df.format(num);
	}

	/**
	 * Convert Byte to KB
	 */
	public static double getKFromByte(long byteSize) {
		return ((double) byteSize) / 1024;
	}

	/**
	 * Convert Byte to MB
	 */
	public static double getMFromByte(long byteSize) {
		return getKFromByte(byteSize) / 1024;
	}

	/**
	 * Convert Byte to GB
	 */
	public static double getGFromByte(long byteSize) {
		return getMFromByte(byteSize) / 1024;
	}

	/**
	 * Convert Byte to TB
	 */
	public static double getTFromByte(long byteSize) {
		return getMFromByte(byteSize) / 1024;
	}

	/**
	 * Convert Byte to (KB or MB orGB)
	 */
	public static String getFormatSizeFromByte(long byteSize) {
		// B
		if (byteSize < 1024) {
			return getFormatDigit(byteSize, FORMAT_4);

			// KB
		} else if (byteSize < 1024 * 1024) {
			return getFormatDigit(getKFromByte(byteSize), FORMAT_5);

			// MB
		} else if (byteSize < 1024 * 1024 * 1024) {
			return getFormatDigit(getMFromByte(byteSize), FORMAT_1);

			// GB
		} else if (byteSize < 1024 * 1024 * 1024 * 1024) {
			return getFormatDigit(getGFromByte(byteSize), FORMAT_3);
		}

		// TB
		return getFormatDigit(getTFromByte(byteSize), FORMAT_6);
	}
}
