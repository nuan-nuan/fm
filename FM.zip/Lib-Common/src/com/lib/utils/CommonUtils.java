package com.lib.utils;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Environment;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.SpannedString;
import android.text.style.AbsoluteSizeSpan;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

/**
 * 常用共同方法类，不涉及逻辑
 * 
 * @author Jun.Wang
 */
public class CommonUtils {
	/**
	 * 检测字符串是否为空
	 * 
	 * 空格，null，"" 一律为空
	 * 
	 * true ：空 ； false ： 不为空
	 * 
	 */
	public static boolean isEmpty(String str) {

		boolean isEmpty = false;

		if (str == null || "".equals(str) || "".equals(str.trim())) {
			isEmpty = true;
		}

		return isEmpty;
	}

	/**
	 * 是否打开蓝牙，及蓝牙是否可用
	 * 
	 * @return true: 已打开; false: 未开启
	 */
	@SuppressLint("InlinedApi")
	public static boolean isBluetoothActive(Context cxt) {
		return ((BluetoothManager) cxt.getSystemService(Context.BLUETOOTH_SERVICE)).getAdapter().isEnabled();
	}

	/**
	 * 检测WIFI状态
	 * 
	 * @return true: 有网络; false: 没有网络
	 */
	public static boolean isWifiActive(Context cxt) {

		//
		boolean isActive = false;

		//
		ConnectivityManager cm = (ConnectivityManager) cxt.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo wifiInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);

		// WIFI
		if (wifiInfo != null) {
			if (wifiInfo.getState() == NetworkInfo.State.CONNECTED) {
				isActive = true;
			}
		}

		return isActive;
	}

	/**
	 * 检测网络状态
	 * 
	 * @return true: 有网络; false: 没有网络
	 */
	public static boolean isNetWorkActive(Context cxt) {
		//
		boolean isActive = false;

		//
		ConnectivityManager cm = (ConnectivityManager) cxt.getSystemService(Context.CONNECTIVITY_SERVICE);

		// 手机网
		NetworkInfo mobileInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
		if (mobileInfo != null) {
			if (mobileInfo.getState() == NetworkInfo.State.CONNECTED) {
				isActive = true;
			}
		}

		// WIFI
		NetworkInfo wifiInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		if (wifiInfo != null) {
			if (wifiInfo.getState() == NetworkInfo.State.CONNECTED) {
				isActive = true;
			}
		}

		return isActive;
	}

	/**
	 * 检测GPS是否可用
	 * 
	 * @return true: 可用; false: 不可用
	 */
	public static boolean isGPSActive(Context cxt) {
		LocationManager locationManager = ((LocationManager) cxt.getSystemService(Context.LOCATION_SERVICE));
		return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
	}

	/**
	 * 检测SD卡是否可用
	 */
	public static boolean isSDCardActive() {
		boolean isActive = false;

		if (Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED)) {
			isActive = true;
		}

		return isActive;
	}

	/**
	 * 检测电话号码格式
	 */
	public static boolean isTelActive(String telNo) {

		boolean isTelActive = false;
		if (isEmpty(telNo)) {
			return isTelActive;
		}

		// String expression =
		// "((^(11|12|13|14|15|16|17|18|19)[0-9]{9}$)|(^0[1,2]{1}\\d{1}-?\\d{8}$)|(^0[3-9] {1}\\d{2}-?\\d{7,8}$)|(^0[1,2]{1}\\d{1}-?\\d{8}-(\\d{1,4})$)|(^0[3-9]{1}\\d{2}-? \\d{7,8}-(\\d{1,4})$))";
		String regExp = "^((13[0-9])|147|(15[^4,\\D])|170|(18[0-9]))\\d{8}$";
		Pattern pattern = Pattern.compile(regExp);
		Matcher matcher = pattern.matcher(telNo);
		isTelActive = matcher.matches();

		return isTelActive;
	}

	/**
	 * 检测邮箱地址格式
	 */
	public static boolean isEmailActive(String email) {

		boolean isEmailActive = false;
		if (isEmpty(email)) {
			return isEmailActive;
		}

		String regExp = "^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$";
		Pattern pattern = Pattern.compile(regExp);
		Matcher matcher = pattern.matcher(email);
		isEmailActive = matcher.matches();

		return isEmailActive;
	}

	/**
	 * 密码格式是否正确
	 * 
	 * 格式：6-16位数字或字母作为密码
	 */
	public static boolean isPwdActive(String pwd) {
		boolean isActive = false;

		if (pwd.length() >= 6 && pwd.length() <= 16) {
			isActive = true;
		}

		return isActive;
	}

	/**
	 * 打开WIFI设置页面
	 */
	public static void openWifiSettings(Context cxt) {
		Intent intent = new Intent("android.settings.WIFI_SETTINGS");
		cxt.startActivity(intent);
	}

	/**
	 * 打开GPS设置页面
	 */
	public static void openGPSSet() {
		Intent intent = new Intent();
		intent.setAction(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	}

	/**
	 * 显示软键盘
	 */
	public static void showSoftKeyBoard(Context cxt) {
		InputMethodManager imm = (InputMethodManager) cxt.getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
	}

	/**
	 * 关闭软键盘
	 */
	public static void hideSoftKeyBoard(Context cxt, View focusV) {
		if (focusV != null) {
			InputMethodManager imm = (InputMethodManager) cxt.getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(focusV.getWindowToken(), 0);
		}
	}

	/**
	 * 将px值转换为dip或dp值，保证尺寸大小不变
	 * 
	 * @param pxValue
	 * @param scale
	 *            （DisplayMetrics类中属性density）
	 * @return
	 */
	public static int px2dip(Context cxt, float pxValue) {
		final float scale = cxt.getResources().getDisplayMetrics().density;
		return (int) (pxValue / scale + 0.5f);
	}

	/**
	 * 将dip或dp值转换为px值，保证尺寸大小不变
	 * 
	 * @param dipValue
	 * @param scale
	 *            （DisplayMetrics类中属性density）
	 * @return
	 */
	public static int dip2px(Context cxt, float dipValue) {
		final float scale = cxt.getResources().getDisplayMetrics().density;
		return (int) (dipValue * scale + 0.5f);
	}

	/**
	 * 将px值转换为sp值，保证文字大小不变
	 * 
	 * @param pxValue
	 * @param fontScale
	 *            （DisplayMetrics类中属性scaledDensity）
	 * @return
	 */
	public static int px2sp(Context cxt, float pxValue) {
		final float fontScale = cxt.getResources().getDisplayMetrics().scaledDensity;
		return (int) (pxValue / fontScale + 0.5f);
	}

	/**
	 * 将sp值转换为px值，保证文字大小不变
	 * 
	 * @param spValue
	 * @param fontScale
	 *            （DisplayMetrics类中属性scaledDensity）
	 * @return
	 */
	public static int sp2px(Context cxt, float spValue) {
		final float fontScale = cxt.getResources().getDisplayMetrics().scaledDensity;
		return (int) (spValue * fontScale + 0.5f);
	}

	/**
	 * 移动设备信息
	 * 
	 * @return String[]:
	 *         <P>
	 *         [0] 移动设备国际识别码,是手机的唯一识别号码
	 *         <p>
	 *         [1] "Android"
	 *         <p>
	 *         [2] SDK Version
	 *         <p>
	 *         [3] MODEL
	 */
	public static String[] getTelIMEI(Context cxt) {
		TelephonyManager telManager = (TelephonyManager) cxt.getSystemService(Context.TELEPHONY_SERVICE);

		// 移动设备国际识别码,是手机的唯一识别号码
		String[] telInfo = new String[4];
		telInfo[0] = telManager.getDeviceId();
		telInfo[1] = "Android";
		telInfo[2] = android.os.Build.VERSION.RELEASE;
		telInfo[3] = android.os.Build.MODEL;

		return telInfo;
	}

	/**
	 * 拨打电话
	 * 
	 * @param telNum
	 *            : 电话号码
	 * @param isJustDial
	 *            ： 是否直接拨号
	 */
	public static void dialTel(Context cxt, String telNum, boolean isJustDial) {
		// 直接拨打电话
		if (isJustDial) {
			Intent justDialIntent = new Intent(Intent.ACTION_CALL);
			justDialIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			Uri data = Uri.parse("tel:" + telNum);
			justDialIntent.setData(data);
			cxt.startActivity(justDialIntent);

			// 进入拨号页面，由用户决定是否真正拨打电话
		} else {
			Intent dialIntent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + telNum));
			dialIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			cxt.startActivity(dialIntent);
		}
	}

	/**
	 * 发送短信
	 */
	public static void sendSMS(Context cxt, String telNum) {
		Uri uri = Uri.parse("smsto:" + telNum);
		Intent smsIntent = new Intent(Intent.ACTION_SENDTO, uri);
		smsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		cxt.startActivity(smsIntent);
	}

	/**
	 * 发送邮件
	 */
	public static void sendEmail(Context cxt, String emailAddr) {
		Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
		emailIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		emailIntent.setData(Uri.parse("mailto:" + emailAddr));
		// emailIntent.putExtra(Intent.EXTRA_SUBJECT, "这是标题");
		// emailIntent.putExtra(Intent.EXTRA_TEXT, "这是内容");
		cxt.startActivity(emailIntent);
	}

	/**
	 * 获取固定字体设置
	 * 
	 * @param spanSize
	 *            : Font Size
	 */
	public static SpannedString getFixedSpannedStr(int spanSize, String hintTxt) {
		AbsoluteSizeSpan ass = new AbsoluteSizeSpan(spanSize, true);

		SpannableString ss = new SpannableString(hintTxt);
		ss.setSpan(ass, 0, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

		return new SpannedString(ss);
	}

	/**
	 * Bring View to Front
	 */
	public static void bringViewFront(View v) {
		v.bringToFront();
		v.requestLayout();
	}

	/**
	 * Get Inner storage.
	 */
	public static File getInnerStorage() {
		return Environment.getExternalStorageDirectory();
	}

	/**
	 * 16进制的字符串表示转成字节数组
	 * 
	 * @param hexString
	 *            16进制格式的字符串
	 * @return 转换后的字节数组
	 **/
	public static byte[] hexStr2ByteArray(String hexString) {
		hexString = hexString.toLowerCase();
		final byte[] byteArray = new byte[hexString.length() / 2];
		int k = 0;
		for (int i = 0; i < byteArray.length; i++) {
			// 因为是16进制，最多只会占用4位，转换成字节需要两个16进制的字符，高位在先
			// 将hex 转换成byte "&" 操作为了防止负数的自动扩展
			// hex转换成byte 其实只占用了4位，然后把高位进行右移四位
			// 然后“|”操作 低四位 就能得到 两个 16进制数转换成一个byte.
			//
			byte high = (byte) (Character.digit(hexString.charAt(k), 16) & 0xff);
			byte low = (byte) (Character.digit(hexString.charAt(k + 1), 16) & 0xff);
			byteArray[i] = (byte) (high << 4 | low);
			k += 2;
		}
		return byteArray;
	}

	/**
	 * Get Formated MAC String
	 * 
	 * @param strMacNum
	 *            : Format Must Be "223456789910"
	 * @return like "22:34:56:78:99:10"
	 */
	public static String getMacFromMacStr(String strMacNum, boolean isUpperCase) {
		//
		if (isEmpty(strMacNum) || strMacNum.length() != 12) {
			return "";
		}

		//
		if (isUpperCase) {
			strMacNum = strMacNum.toUpperCase();
		} else {
			strMacNum = strMacNum.toLowerCase();
		}

		//
		StringBuffer strFormatMAC = new StringBuffer("");
		strFormatMAC.append(strMacNum.substring(0, 2) + ":");
		strFormatMAC.append(strMacNum.substring(2, 4) + ":");
		strFormatMAC.append(strMacNum.substring(4, 6) + ":");
		strFormatMAC.append(strMacNum.substring(6, 8) + ":");
		strFormatMAC.append(strMacNum.substring(8, 10) + ":");
		strFormatMAC.append(strMacNum.substring(10, 12));

		return strFormatMAC.toString();
	}

	/**
	 * Set view Enable and alpha
	 */
	public static void setViewEnable(View v, boolean isEnable) {
		//
		v.setEnabled(isEnable);

		//
		if (isEnable) {
			v.setAlpha(1f);
		} else {
			v.setAlpha(0.5f);
		}
	}
}
