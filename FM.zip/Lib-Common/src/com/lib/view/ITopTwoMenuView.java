package com.lib.view;

import android.view.View;
import android.widget.TextView;

import com.lib.R;

/**
 * Top tab, has two option menus
 * 
 * (1) Include below layout where you need
 * <p>
 * <include android:id="@+id/top_tab_two" android:layout_width="match_parent"
 * android:layout_height="wrap_content" layout="@layout/v_tab_two_menu" />
 * 
 * (2) INIT in java where you need like below
 * <p>
 * ITopTwoMenuView initV = new ITopTwoMenuView(findViewById(R.id.top_tab_two));
 * 
 * (3) Then you can use methods of ITopTwoMenuView
 * 
 * @author Jun.Wang
 */
public class ITopTwoMenuView {

	/**
	 * Left Operate Button / Right Operate Button
	 */
	private TextView btnLeft, btnRight;

	/**
	 * Left Bottom Line / Right Button Line
	 */
	private View vLeftBottom, vRightBottom;

	/**
	 * Left or Right Mode
	 */
	public interface TopMenuMode {
		public final int LEFT_MODE = 1;
		public final int RIGHT_MODE = 2;
	}

	/**
	 * Constructor
	 * 
	 * @param v
	 *            : top two menu layout
	 */
	public ITopTwoMenuView(View v) {
		//
		if (v == null) {
			return;
		}

		//
		btnLeft = (TextView) v.findViewById(R.id.btn_left_menu);
		btnRight = (TextView) v.findViewById(R.id.btn_right_menu);

		vLeftBottom = v.findViewById(R.id.v_bottom_1);
		vRightBottom = v.findViewById(R.id.v_bottom_2);
	}

	/**
	 * Set select mode
	 * 
	 * @see TopTwoMenu
	 */
	public void setMode(int mode) {
		// Left
		if (mode == TopMenuMode.LEFT_MODE) {
			vLeftBottom.setVisibility(View.VISIBLE);
		} else {
			vLeftBottom.setVisibility(View.INVISIBLE);
		}

		// Right
		if (mode == TopMenuMode.RIGHT_MODE) {
			vRightBottom.setVisibility(View.VISIBLE);
		} else {
			vRightBottom.setVisibility(View.INVISIBLE);
		}
	}

	/**
	 * Left Menu View ID
	 */
	public int getLeftId() {
		return btnLeft.getId();
	}

	/**
	 * Right Menu View ID
	 */
	public int getRightId() {
		return btnRight.getId();
	}

	/**
	 * Set Left Menu Text
	 */
	public void setLeftText(String strText) {
		btnLeft.setText(strText);
	}

	/**
	 * Set Right Menu Text
	 */
	public void setRightText(String strText) {
		btnRight.setText(strText);
	}

	/**
	 * Set Left Menu Text Color
	 */
	public void setLeftTextColor(int color) {
		btnLeft.setTextColor(color);
	}

	/**
	 * Set Right Menu Text Color
	 */
	public void setRightTextColor(int color) {
		btnRight.setTextColor(color);
	}

	/**
	 * Left Menu Click Listener
	 */
	public void setLeftClickListener(View.OnClickListener l) {
		btnLeft.setOnClickListener(l);
	}

	/**
	 * Right Menu Click Listener
	 */
	public void setRightClickListener(View.OnClickListener l) {
		btnRight.setOnClickListener(l);
	}
}
