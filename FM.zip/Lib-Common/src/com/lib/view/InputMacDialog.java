package com.lib.view;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.lib.R;
import com.lib.utils.CommonUtils;
import com.lib.utils.Logs;

/**
 * MAC Input Dialog
 * 
 * @author Jun.Wang
 */
public class InputMacDialog extends AlertDialog {
	/**
	 * Context
	 */
	private Context mContext;

	/**
	 * Input Content
	 */
	private EditText etMac1, etMac2, etMac3, etMac4, etMac5, etMac6;
	/**
	 * MAC Nodes
	 */
	private String mMac1 = "", mMac2 = "", mMac3 = "", mMac4 = "", mMac5 = "", mMac6 = "";

	/**
	 * Operate Buttons
	 */
	private TextView btnOperate1, btnOperate2;

	/**
	 * Operate1 Text / Operate2 Text
	 */
	private String mOperate1Txt = "", mOperate2Txt = "";

	/**
	 * Operate1 click listener / Operate2 click listener
	 */
	private View.OnClickListener mOperate1OnClick, mOperate2OnClick;

	/**
	 * Input Key Code
	 */
	private int mInputKeyCode = -1;

	public InputMacDialog(Context context) {
		super(context);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.v_input_mac_dialog);

		etMac1 = (EditText) findViewById(R.id.et_mac_1);
		etMac1.addTextChangedListener(new EtMac1OnChange());

		etMac2 = (EditText) findViewById(R.id.et_mac_2);
		etMac2.addTextChangedListener(new EtMac2OnChange());

		etMac3 = (EditText) findViewById(R.id.et_mac_3);
		etMac3.addTextChangedListener(new EtMac3OnChange());

		etMac4 = (EditText) findViewById(R.id.et_mac_4);
		etMac4.addTextChangedListener(new EtMac4OnChange());

		etMac5 = (EditText) findViewById(R.id.et_mac_5);
		etMac5.addTextChangedListener(new EtMac5OnChange());

		etMac6 = (EditText) findViewById(R.id.et_mac_6);
		etMac6.addTextChangedListener(new EtMac6OnChange());

		//
		btnOperate1 = (TextView) findViewById(R.id.btn_operate_1);
		btnOperate1.setOnClickListener(mOperate1OnClick);
		if (!TextUtils.isEmpty(mOperate1Txt)) {
			btnOperate1.setText(mOperate1Txt);
		}

		//
		btnOperate2 = (TextView) findViewById(R.id.btn_operate_2);
		btnOperate2.setOnClickListener(mOperate2OnClick);
		if (!TextUtils.isEmpty(mOperate2Txt)) {
			btnOperate2.setText(mOperate2Txt);
		}
	}

	/**
	 * Operate First
	 */
	public void setOperate1Txt(int resID) {
		setOperate1Txt(mContext.getString(resID));
	}

	/**
	 * Operate First
	 */
	public void setOperate1Txt(CharSequence operate1Txt) {
		if (operate1Txt != null) {
			mOperate1Txt = operate1Txt.toString();
		}
	}

	/**
	 * Operate Second
	 */
	public void setOperate2Txt(int resID) {
		setOperate2Txt(mContext.getString(resID));
	}

	/**
	 * Operate Twice
	 */
	public void setOperate2Txt(CharSequence operate2Txt) {
		if (operate2Txt != null) {
			mOperate2Txt = operate2Txt.toString();
		}
	}

	/**
	 * Operate First Click Listener
	 */
	public void setOperate1OnClick(View.OnClickListener l) {
		mOperate1OnClick = l;
	}

	/**
	 * Operate Second Click Listener
	 */
	public void setOperate2OnClick(View.OnClickListener l) {
		mOperate2OnClick = l;
	}

	/**
	 * Check if MAC filter enable
	 */
	public boolean isMacFilterEnable(boolean isShowToast) {
		//
		boolean isEnable = true;

		// Check Null
		if (CommonUtils.isEmpty(mMac1)
				|| CommonUtils.isEmpty(mMac1)
				|| CommonUtils.isEmpty(mMac1)
				|| CommonUtils.isEmpty(mMac1)
				|| CommonUtils.isEmpty(mMac1)
				|| CommonUtils.isEmpty(mMac1)) {
			isEnable = false;
			if (isShowToast) {
				Toast.makeText(mContext, R.string.plea_input_all_info, Toast.LENGTH_SHORT).show();
			}

			// Check Format
		} else if (mMac1.length() != 2 || mMac1.length() != 2 || mMac1.length() != 2 || mMac1.length() != 2) {
			isEnable = false;
			if (isShowToast) {
				Toast.makeText(mContext, R.string.mac_format_error, Toast.LENGTH_SHORT).show();
			}
		}

		return isEnable;
	}

	/**
	 * Get MAC
	 */
	public String getMac() {
		return (mMac1 + "-" + mMac2 + "-" + mMac3 + "-" + mMac4 + "-" + mMac5 + "-" + mMac6).toUpperCase();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		mInputKeyCode = keyCode;
		return super.onKeyDown(keyCode, event);
	}

	/**
	 * Mac1 OnChange
	 */
	public class EtMac1OnChange implements TextWatcher {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			mMac1 = s.toString().trim();
			if (mMac1.length() == 2) {
				etMac1.clearFocus();
				etMac2.requestFocus();
			}
		}
	}

	/**
	 * Mac2 OnChange
	 */
	public class EtMac2OnChange implements TextWatcher {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			mMac2 = s.toString().trim();
			if (mMac2.length() == 2) {
				etMac2.clearFocus();
				etMac3.requestFocus();

				// 回退键
			} else if (mMac2.length() == 0) {
				if (mInputKeyCode == 67) {
					etMac2.clearFocus();
					etMac1.requestFocus();
				}
			}
		}
	}

	/**
	 * Mac3 OnChange
	 */
	public class EtMac3OnChange implements TextWatcher {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			mMac3 = s.toString().trim();
			if (mMac3.length() == 2) {
				etMac3.clearFocus();
				etMac4.requestFocus();

				// 回退键
			} else if (mMac3.length() == 0) {
				if (mInputKeyCode == 67) {
					etMac3.clearFocus();
					etMac2.requestFocus();
				}
			}
		}
	}

	/**
	 * Mac4 OnChange
	 */
	public class EtMac4OnChange implements TextWatcher {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			mMac4 = s.toString().trim();
			if (mMac4.length() == 2) {
				etMac4.clearFocus();
				etMac5.requestFocus();

				// 回退键
			} else if (mMac4.length() == 0) {
				if (mInputKeyCode == 67) {
					etMac4.clearFocus();
					etMac3.requestFocus();
				}
			}
		}
	}

	/**
	 * Mac5 OnChange
	 */
	public class EtMac5OnChange implements TextWatcher {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			mMac5 = s.toString().trim();
			if (mMac5.length() == 2) {
				etMac5.clearFocus();
				etMac6.requestFocus();

				// 回退键
			} else if (mMac5.length() == 0) {
				if (mInputKeyCode == 67) {
					etMac5.clearFocus();
					etMac4.requestFocus();
				}
			}
		}
	}

	/**
	 * Mac6 OnChange
	 */
	public class EtMac6OnChange implements TextWatcher {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			Logs.i("EtMac6OnChange", "--1-->>>" + s.toString().trim().length());
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			mMac6 = s.toString().trim();
			Logs.i("EtMac6OnChange", "--2-->>>" + s.toString().trim().length());

			// 回退键
			if (mMac6.length() == 0) {
				if (mInputKeyCode == 67) {
					etMac6.clearFocus();
					etMac5.requestFocus();
				}
			}
		}
	}

	@Override
	public void show() {
		super.show();
		getWindow().clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
	}
}
