package com.lib.view;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.lib.R;
import com.lib.utils.CommonUtils;

/**
 * IP input dialog
 * 
 * @author Jun.Wang
 */
public class InputIPDialog extends AlertDialog {
	/**
	 * Context
	 */
	private Context mContext;

	/**
	 * Input Content
	 */
	private EditText etSIp1, etSIp2, etSIp3, etSIp4, etEIp1, etEIp2, etEIp3, etEIp4;
	/**
	 * IP Nodes
	 */
	private String mSIp1 = "", mSIp2 = "", mSIp3 = "", mSIp4 = "", mEIp1 = "", mEIp2 = "", mEIp3 = "", mEIp4 = "";

	/**
	 * Operate Buttons
	 */
	private TextView btnOperate1, btnOperate2;

	/**
	 * Operate1 Text / Operate2 Text
	 */
	private String mOperate1Txt = "", mOperate2Txt = "";

	/**
	 * Operate1 click listener / Operate2 click listener
	 */
	private View.OnClickListener mOperate1OnClick, mOperate2OnClick;

	/**
	 * Input Key Code
	 */
	private int mInputKeyCode = -1;

	public InputIPDialog(Context context) {
		super(context);
		mContext = context;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.v_input_ip_dialog);

		//
		etSIp1 = (EditText) findViewById(R.id.et_ip_s_1);
		etSIp1.addTextChangedListener(new EtSIp1OnChange());

		etSIp2 = (EditText) findViewById(R.id.et_ip_s_2);
		etSIp2.addTextChangedListener(new EtSIp2OnChange());

		etSIp3 = (EditText) findViewById(R.id.et_ip_s_3);
		etSIp3.addTextChangedListener(new EtSIp3OnChange());

		etSIp4 = (EditText) findViewById(R.id.et_ip_s_4);
		etSIp4.addTextChangedListener(new EtSIp4OnChange());

		//
		etEIp1 = (EditText) findViewById(R.id.et_ip_e_1);
		etEIp1.addTextChangedListener(new EtEIp1OnChange());

		etEIp2 = (EditText) findViewById(R.id.et_ip_e_2);
		etEIp2.addTextChangedListener(new EtEIp2OnChange());

		etEIp3 = (EditText) findViewById(R.id.et_ip_e_3);
		etEIp3.addTextChangedListener(new EtEIp3OnChange());

		etEIp4 = (EditText) findViewById(R.id.et_ip_e_4);
		etEIp4.addTextChangedListener(new EtEIp4OnChange());

		//
		btnOperate1 = (TextView) findViewById(R.id.btn_operate_1);
		btnOperate1.setOnClickListener(mOperate1OnClick);
		if (!TextUtils.isEmpty(mOperate1Txt)) {
			btnOperate1.setText(mOperate1Txt);
		}

		//
		btnOperate2 = (TextView) findViewById(R.id.btn_operate_2);
		btnOperate2.setOnClickListener(mOperate2OnClick);
		if (!TextUtils.isEmpty(mOperate2Txt)) {
			btnOperate2.setText(mOperate2Txt);
		}
	}

	/**
	 * Operate First
	 */
	public void setOperate1Txt(int resID) {
		setOperate1Txt(mContext.getString(resID));
	}

	/**
	 * Operate First
	 */
	public void setOperate1Txt(CharSequence operate1Txt) {
		if (operate1Txt != null) {
			mOperate1Txt = operate1Txt.toString();
		}
	}

	/**
	 * Operate Second
	 */
	public void setOperate2Txt(int resID) {
		setOperate2Txt(mContext.getString(resID));
	}

	/**
	 * Operate Twice
	 */
	public void setOperate2Txt(CharSequence operate2Txt) {
		if (operate2Txt != null) {
			mOperate2Txt = operate2Txt.toString();
		}
	}

	/**
	 * Operate First Click Listener
	 */
	public void setOperate1OnClick(View.OnClickListener l) {
		mOperate1OnClick = l;
	}

	/**
	 * Operate Second Click Listener
	 */
	public void setOperate2OnClick(View.OnClickListener l) {
		mOperate2OnClick = l;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		mInputKeyCode = keyCode;
		return super.onKeyDown(keyCode, event);
	}

	/**
	 * Start Ip1 OnChange
	 */
	public class EtSIp1OnChange implements TextWatcher {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			mSIp1 = s.toString().trim();
			if (mSIp1.length() == 3) {
				etSIp1.clearFocus();
				etSIp2.requestFocus();
			}
		}
	}

	/**
	 * Start Ip2 OnChange
	 */
	public class EtSIp2OnChange implements TextWatcher {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			mSIp2 = s.toString().trim();
			if (mSIp2.length() == 3) {
				etSIp2.clearFocus();
				etSIp3.requestFocus();

				// 回退键
			} else if (mSIp2.length() == 0) {
				if (mInputKeyCode == 67) {
					etSIp2.clearFocus();
					etSIp1.requestFocus();
				}
			}
		}
	}

	/**
	 * Start Ip3 OnChange
	 */
	public class EtSIp3OnChange implements TextWatcher {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			mSIp3 = s.toString().trim();
			if (mSIp3.length() == 3) {
				etSIp3.clearFocus();
				etSIp4.requestFocus();

				// 回退键
			} else if (mSIp3.length() == 0) {
				if (mInputKeyCode == 67) {
					etSIp3.clearFocus();
					etSIp2.requestFocus();
				}
			}
		}
	}

	/**
	 * Start Ip4 OnChange
	 */
	public class EtSIp4OnChange implements TextWatcher {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			mSIp4 = s.toString().trim();

			// 回退键
			if (mSIp4.length() == 0) {
				if (mInputKeyCode == 67) {
					etSIp4.clearFocus();
					etSIp3.requestFocus();
				}
			}
		}
	}

	/**
	 * End Ip1 OnChange
	 */
	public class EtEIp1OnChange implements TextWatcher {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			mEIp1 = s.toString().trim();
			if (mEIp1.length() == 3) {
				etEIp1.clearFocus();
				etEIp2.requestFocus();
			}
		}
	}

	/**
	 * End Ip2 OnChange
	 */
	public class EtEIp2OnChange implements TextWatcher {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			mEIp2 = s.toString().trim();
			if (mEIp2.length() == 3) {
				etEIp2.clearFocus();
				etEIp3.requestFocus();

				// 回退键
			} else if (mEIp2.length() == 0) {
				if (mInputKeyCode == 67) {
					etEIp2.clearFocus();
					etEIp1.requestFocus();
				}
			}
		}
	}

	/**
	 * End Ip3 OnChange
	 */
	public class EtEIp3OnChange implements TextWatcher {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			mEIp3 = s.toString().trim();
			if (mEIp3.length() == 3) {
				etEIp3.clearFocus();
				etEIp4.requestFocus();

				// 回退键
			} else if (mEIp3.length() == 0) {
				if (mInputKeyCode == 67) {
					etEIp3.clearFocus();
					etEIp2.requestFocus();
				}
			}
		}
	}

	/**
	 * End Ip4 OnChange
	 */
	public class EtEIp4OnChange implements TextWatcher {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			mEIp4 = s.toString().trim();

			// 回退键
			if (mEIp4.length() == 0) {
				if (mInputKeyCode == 67) {
					etEIp4.clearFocus();
					etEIp3.requestFocus();
				}
			}
		}
	}

	/**
	 * Check if IP filter information whole input.
	 */
	public boolean isIpFilterEnable(boolean isShowToast) {
		//
		if (CommonUtils.isEmpty(mSIp1) || CommonUtils.isEmpty(mSIp2) || CommonUtils.isEmpty(mSIp3) || CommonUtils.isEmpty(mSIp4)
				|| CommonUtils.isEmpty(mEIp1) || CommonUtils.isEmpty(mEIp2) || CommonUtils.isEmpty(mEIp3) || CommonUtils.isEmpty(mEIp4)) {
			if (isShowToast) {
				Toast.makeText(mContext, R.string.plea_input_all_info, Toast.LENGTH_SHORT).show();
			}
			return false;
		}

		//
		try {
			int sNum1 = Integer.valueOf(mSIp1);
			int sNum2 = Integer.valueOf(mSIp2);
			int sNum3 = Integer.valueOf(mSIp3);
			int sNum4 = Integer.valueOf(mSIp4);

			int eNum1 = Integer.valueOf(mEIp1);
			int eNum2 = Integer.valueOf(mEIp2);
			int eNum3 = Integer.valueOf(mEIp3);
			int eNum4 = Integer.valueOf(mEIp4);

			if (sNum1 > 255 || sNum2 > 255 || sNum3 > 255 || sNum4 > 255 || eNum1 > 255 || eNum2 > 255 || eNum3 > 255 || eNum4 > 255) {
				if (isShowToast) {
					Toast.makeText(mContext, R.string.ip_format_error, Toast.LENGTH_SHORT).show();
				}
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	/**
	 * Get formatted start IP
	 */
	public String getStartIP() {
		return mSIp1 + "." + mSIp2 + "." + mSIp3 + "." + mSIp4;
	}

	/**
	 * Get formatted start IP
	 */
	public String getEndIP() {
		return mEIp1 + "." + mEIp2 + "." + mEIp3 + "." + mEIp4;
	}

	@Override
	public void show() {
		super.show();
		getWindow().clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
	}
}
