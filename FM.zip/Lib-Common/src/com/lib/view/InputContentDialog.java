package com.lib.view;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;

import com.lib.R;
import com.lib.utils.CommonUtils;

/**
 * Content Input Dialog
 * 
 * @author Jun.Wang
 */
public class InputContentDialog extends AlertDialog {

	/**
	 * Context
	 */
	private Context mContext;

	/**
	 * Title
	 */
	private TextView tvTitle;

	/**
	 * Input Content
	 */
	private EditText etContent;

	/**
	 * Operate Buttons
	 */
	private TextView btnOperate1, btnOperate2;

	/**
	 * Operate1 Text / Operate2 Text
	 */
	private String mTilte = "", mContent = "", mOperate1Txt = "", mOperate2Txt = "";

	/**
	 * Operate1 click listener / Operate2 click listener
	 */
	private View.OnClickListener mOperate1OnClick, mOperate2OnClick;

	public InputContentDialog(Context context) {
		super(context);
		mContext = context;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.v_input_content_dialog);

		//
		tvTitle = (TextView) findViewById(R.id.tv_title);
		if (!TextUtils.isEmpty(mTilte)) {
			tvTitle.setText(mTilte);
		}

		etContent = (EditText) findViewById(R.id.et_content);
		etContent.addTextChangedListener(new EtContentTextChange());
		if (!TextUtils.isEmpty(mContent)) {
			etContent.setText(mContent);
		}

		//
		btnOperate1 = (TextView) findViewById(R.id.btn_operate_1);
		btnOperate1.setOnClickListener(mOperate1OnClick);
		if (!TextUtils.isEmpty(mOperate1Txt)) {
			btnOperate1.setText(mOperate1Txt);
		}

		//
		btnOperate2 = (TextView) findViewById(R.id.btn_operate_2);
		btnOperate2.setOnClickListener(mOperate2OnClick);
		if (!TextUtils.isEmpty(mOperate2Txt)) {
			btnOperate2.setText(mOperate2Txt);
		}
	}

	/**
	 * Set input Content
	 */
	public void setInputContent(String content) {
		if (content != null) {
			mContent = content;
			if (etContent != null) {
				etContent.setText(content);
			}
		}
	}

	public void setTitle(int titleId) {
		setTitle(mContext.getString(titleId));
	}

	public void setTitle(String title) {
		if (title != null) {
			mTilte = title;
		}
	}

	/**
	 * Operate First
	 */
	public void setOperate1Txt(int resID) {
		setOperate1Txt(mContext.getString(resID));
	}

	/**
	 * Operate First
	 */
	public void setOperate1Txt(String operate1Txt) {
		if (operate1Txt != null) {
			mOperate1Txt = operate1Txt;
		}
	}

	/**
	 * Operate Second
	 */
	public void setOperate2Txt(int resID) {
		setOperate2Txt(mContext.getString(resID));
	}

	/**
	 * Operate Twice
	 */
	public void setOperate2Txt(CharSequence operate2Txt) {
		if (operate2Txt != null) {
			mOperate2Txt = operate2Txt.toString();
		}
	}

	/**
	 * Operate First Click Listener
	 */
	public void setOperate1OnClick(View.OnClickListener l) {
		mOperate1OnClick = l;
	}

	/**
	 * Operate Second Click Listener
	 */
	public void setOperate2OnClick(View.OnClickListener l) {
		mOperate2OnClick = l;
	}

	/**
	 * 
	 * @author 409157
	 * 
	 */
	public class EtContentTextChange implements TextWatcher {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			mContent = s.toString().trim();
		}
	}

	/**
	 * Get Content
	 */
	public String getContent() {
		if (etContent == null) {
			return "";
		}

		return etContent.getText().toString().trim();
	}

	/**
	 * Check if input content.
	 */
	public boolean isContentEnable(boolean isShowToast) {
		if (CommonUtils.isEmpty(mContent)) {
			return false;
		}

		return true;
	};

	@Override
	public void show() {
		super.show();
		getWindow().clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
	}
}
