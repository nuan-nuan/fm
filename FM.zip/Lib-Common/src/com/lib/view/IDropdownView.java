package com.lib.view;

import java.io.Serializable;
import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.ScrollView;
import android.widget.TextView;

import com.lib.R;
import com.lib.utils.CommonUtils;

/**
 * Drop-down box
 * 
 * @author Jun.Wang
 */
public class IDropdownView extends LinearLayout {

	/**
	 * Selected Item Value text
	 */
	private TextView tvSelected;

	/**
	 * PopupWindow
	 */
	private PopupWindow popItems;

	/**
	 * Context
	 */
	private Context mContext;
	/**
	 * LayoutInflater
	 */
	private LayoutInflater mInflater;

	/**
	 * Item Data list
	 */
	private ArrayList<DropDownItem> mListItems;

	/**
	 * OnSelectChangedListener
	 */
	private OnSelectChangedListener mSelectChangedListener;

	/**
	 * Constructor
	 */
	public IDropdownView(Context context) {
		super(context);

		//
		init(context);
	}

	/**
	 * Constructor
	 */
	public IDropdownView(Context context, AttributeSet attrs) {
		super(context, attrs);

		//
		init(context);
	}

	/**
	 * Constructor
	 */
	public IDropdownView(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);

		//
		init(context);
	}

	/**
	 * Initialize When Constructor
	 */
	private void init(Context context) {
		//
		this.mContext = context;
		this.mInflater = LayoutInflater.from(mContext);

		//
		LinearLayout llRoot = (LinearLayout) mInflater.inflate(R.layout.v_idropdown, this, true);

		tvSelected = (TextView) llRoot.findViewById(R.id.tv_selected);
		tvSelected.setOnClickListener(new ViewOnClick());
	}

	/**
	 * Set drop down list data
	 */
	public void setListItems(ArrayList<DropDownItem> listItems) {
		this.mListItems = listItems; 
	}

	/**
	 * Get drop down list data
	 */
	public ArrayList<DropDownItem> getListItems() {
		return mListItems;
	}

	/**
	 * Set selected Text
	 */
	public void setSelectedTxt(String txt) {
		tvSelected.setText(txt);
	}

	/**
	 * View Click Event
	 */
	private class ViewOnClick implements View.OnClickListener {

		@Override
		public void onClick(View v) {
			//
			if (v.getId() == tvSelected.getId()) {
				showPop(true, v);
			}
		}
	}

	/**
	 * Show or close pop
	 */
	private void showPop(boolean isShow, View rootV) {
		//
		if (isShow) {
			if (popItems == null) {
				popItems = makePopItems();
			}

			if (!popItems.isShowing()) {
				popItems.showAsDropDown(rootV);
				setViewStatus(true);
			}

			//
		} else if (popItems != null && popItems.isShowing()) {
			popItems.dismiss();
		}
	}

	/**
	 * Set View Status
	 */
	private void setViewStatus(boolean isPopShow) {
		if (isPopShow) {
			tvSelected.setBackgroundResource(R.drawable.bg_drop_on);
			tvSelected.setTextColor(mContext.getResources().getColor(R.color.font_blue_1));
		} else {
			tvSelected.setBackgroundResource(R.drawable.bg_drop_off);
			tvSelected.setTextColor(mContext.getResources().getColor(R.color.white));
		}
	}

	/**
	 * 
	 * @return
	 */
	@SuppressLint("InflateParams")
	private PopupWindow makePopItems() {
		//
		if (mListItems == null || mListItems.size() == 0) {
			return null;
		}

		//
		ScrollView svContent = (ScrollView) mInflater.inflate(R.layout.v_idropdown_pop, null);
		LinearLayout llContent = (LinearLayout) svContent.findViewById(R.id.ll_drop_content);
		llContent.setBackgroundResource(android.R.color.transparent);

		//
		int loopCount = mListItems.size();
		for (int idx = 0; idx < loopCount; idx++) {
			DropDownItem item = mListItems.get(idx);

			//
			LinearLayout llItem = (LinearLayout) mInflater.inflate(R.layout.v_idropdown_pop_item, null);

			TextView tvItemName = (TextView) llItem.findViewById(R.id.tv_item);
			tvItemName.setText(item.itemName);
			tvItemName.setOnClickListener(new DropItemOnClick(item));

			if (idx == loopCount - 1) {
				llItem.findViewById(R.id.v_seperate_1).setVisibility(View.GONE);
			}

			llContent.addView(llItem);
		}

		//
		int itemH = tvSelected.getHeight() + 2;

		popItems = new PopupWindow(mContext);
		popItems.setWidth(tvSelected.getWidth());
		popItems.setHeight(loopCount < 5 ? loopCount * itemH : 4 * itemH);
		popItems.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.bg_drop_down));
		popItems.setTouchable(true);
		popItems.setOutsideTouchable(true);
		popItems.setFocusable(true);
		popItems.setContentView(svContent);
		popItems.setOnDismissListener(new OnDismissListener() {

			@Override
			public void onDismiss() {
				setViewStatus(false);
			}
		});

		return popItems;
	}

	/**
	 * View Click Event
	 */
	private class DropItemOnClick implements View.OnClickListener {

		public DropDownItem mmItem;

		public DropItemOnClick(DropDownItem item) {
			mmItem = item;
		}

		@Override
		public void onClick(View v) {
			//
			setSelectItem(mmItem);

			//
			if (mSelectChangedListener != null) {
				mSelectChangedListener.afterSelected(mmItem);
			}
		}
	}

	/**
	 * Set select Item
	 */
	public void setSelectItem(DropDownItem item) {
		//
		if (item == null || CommonUtils.isEmpty(item.itemName)) {
			return;
		}

		//
		showPop(false, null);

		//
		if (!TextUtils.equals(item.itemName, tvSelected.getText().toString())) {
			tvSelected.setText(item.itemName);
			tvSelected.setTag(item);
		}
	}

	/**
	 * Get select item
	 */
	public DropDownItem getSelectItem() {
		Object objItem = tvSelected.getTag();
		if (objItem == null) {
			return null;
		}

		return (DropDownItem) objItem;
	}

	/**
	 * Select Change listener
	 */
	public interface OnSelectChangedListener {
		public void afterSelected(DropDownItem dropItem);
	}

	/**
	 * Set Select Change listener
	 */
	public void setOnSelectChangedListener(OnSelectChangedListener listener) {
		mSelectChangedListener = listener;
	}

	/**
	 * Drop down item Bean
	 */
	public static class DropDownItem implements Serializable {

		/**
		 * Serialization
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * Item Name
		 */
		public String itemName = "";
	}
}
