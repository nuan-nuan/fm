package com.lib.download;

import java.util.List;

import android.app.ActivityManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

import com.lidroid.xutils.exception.DbException;
import com.lidroid.xutils.util.LogUtils;

/**
 * Download Service
 * 
 * @author Jun.Wang
 */
public class IDownloadService extends Service {

	/**
	 * @see IDownloadManger
	 */
	private static IDownloadManger mDownloadManger;

	/**
	 * Get DownloadManger
	 */
	public static IDownloadManger getDownloadManager(Context appContext, String dbSavePath, String dbName) {
		// If service is not running , start it.
		if (!isServiceRunning(appContext)) {
			// Intent downloadServiceIntent = new
			// Intent("com.download.service.action");
			Intent downloadServiceIntent = new Intent(appContext, IDownloadService.class);
			appContext.startService(downloadServiceIntent);
		}

		// INIT IDownloadManger
		if (mDownloadManger == null) {
			mDownloadManger = new IDownloadManger(appContext, dbSavePath, dbName);
		}

		return mDownloadManger;
	}

	/**
	 * Constructor
	 */
	public IDownloadService() {
		super();
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();
	}

	// @Override
	// public void onStart(Intent intent, int startId) {
	// super.onStart(intent, startId);
	// }

	@Override
	public void onDestroy() {
		if (mDownloadManger != null) {
			try {
				mDownloadManger.stopAllQueue();
				mDownloadManger.backupDownloadInfoList();
			} catch (DbException e) {
				LogUtils.e(e.getMessage(), e);
			}
		}
		super.onDestroy();
	}

	/**
	 * Check is download service is running
	 * 
	 * @param context
	 * @return
	 */
	public static boolean isServiceRunning(Context context) {
		boolean isRunning = false;

		ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
		List<ActivityManager.RunningServiceInfo> serviceList = activityManager.getRunningServices(Integer.MAX_VALUE);

		if (serviceList == null || serviceList.size() == 0) {
			return false;
		}

		for (int i = 0; i < serviceList.size(); i++) {
			if (serviceList.get(i).service.getClassName().equals(IDownloadService.class.getName())) {
				isRunning = true;
				break;
			}
		}
		return isRunning;
	}
}
