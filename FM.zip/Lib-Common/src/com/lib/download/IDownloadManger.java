package com.lib.download;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.database.Cursor;
import android.text.TextUtils;

import com.lib.utils.Logs;
import com.lidroid.xutils.DbUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.db.converter.ColumnConverter;
import com.lidroid.xutils.db.converter.ColumnConverterFactory;
import com.lidroid.xutils.db.sqlite.ColumnDbType;
import com.lidroid.xutils.db.sqlite.Selector;
import com.lidroid.xutils.exception.DbException;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.HttpHandler;
import com.lidroid.xutils.http.HttpHandler.State;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.util.LogUtils;

/**
 * Manage Download
 * 
 * @author Jun.Wang
 */
public class IDownloadManger {

	/**
	 * Context
	 */
	private Context mContext;

	/**
	 * Max Download Thread Number
	 */
	private int mMaxDownloadThread = 3;

	/**
	 * Download Information List
	 */
	private List<IDownloadInfo> mListDownloadInfos;

	/**
	 * Database operate methods
	 */
	private DbUtils mDbUtils;

	/**
	 * Constructor
	 */
	public IDownloadManger(Context appContext, String dbSavePath, String dbName) {
		try {
			ColumnConverterFactory.registerColumnConverter(HttpHandler.State.class, new HttpHandlerStateConverter());
			mContext = appContext;
			mDbUtils = DbUtils.create(mContext, dbSavePath, dbName);
			mListDownloadInfos = mDbUtils.findAll(Selector.from(IDownloadInfo.class));
		} catch (Exception e) {
			e.printStackTrace();
		}

		//
		if (mListDownloadInfos == null) {
			mListDownloadInfos = new ArrayList<IDownloadInfo>();
		}
	}

	/**
	 * Add new download task
	 * 
	 * @param url
	 *            : File download URL
	 * @param fileName
	 *            : File name
	 * @param target
	 *            : File save path
	 * @param autoResume
	 *            : (1)If target file exist,continue download
	 *            <p>
	 *            (2)If server not support range, resume download
	 * @param autoRename
	 *            : If get file name from request information, rename after
	 *            download finished?
	 * @param callback
	 * @throws DbException
	 */
	public void addNewDownload(String url, String fileName, String target, boolean autoResume, boolean autoRename,
			final RequestCallBack<File> callback) throws DbException {
		final IDownloadInfo downloadInfo = new IDownloadInfo();
		downloadInfo.setDownloadUrl(url);
		downloadInfo.setAutoRename(autoRename);
		downloadInfo.setAutoResume(autoResume);
		downloadInfo.setFileName(fileName);
		downloadInfo.setFileSavePath(target);
		HttpUtils http = new HttpUtils();
		http.configRequestThreadPoolSize(mMaxDownloadThread);
		HttpHandler<File> handler = http.download(url, target, autoResume, autoRename, new ManagerCallBack(downloadInfo, callback));
		downloadInfo.setHandler(handler);
		downloadInfo.setState(handler.getState());
		mListDownloadInfos.add(downloadInfo);
		mDbUtils.saveBindingId(downloadInfo);
	}

	/**
	 * Add new download task
	 * 
	 * @param iDownloadInfo
	 *            : IDownloadInfo Object
	 * @param callback
	 * @throws DbException
	 */
	public void addNewDownload(IDownloadInfo iDownloadInfo, final RequestCallBack<File> callback) throws DbException {
		//
		HttpUtils http = new HttpUtils();
		http.configRequestThreadPoolSize(mMaxDownloadThread);

		HttpHandler<File> handler = http.download(iDownloadInfo.getDownloadUrl(), iDownloadInfo.getFileSavePath(), iDownloadInfo.isAutoResume(),
				iDownloadInfo.isAutoRename(), new ManagerCallBack(iDownloadInfo, callback));
		iDownloadInfo.setHandler(handler);
		iDownloadInfo.setState(handler.getState());

		//
		mListDownloadInfos.add(iDownloadInfo);
		mDbUtils.saveBindingId(iDownloadInfo);
	}

	/**
	 * Resume Download
	 * 
	 * @param index
	 * @param callback
	 * @throws DbException
	 */
	public void resumeDownload(int index, final RequestCallBack<File> callback) throws DbException {
		final IDownloadInfo downloadInfo = mListDownloadInfos.get(index);
		resumeDownload(downloadInfo, callback);
	}

	/**
	 * Resume Download
	 * 
	 * @param downloadInfo
	 * @param callback
	 * @throws DbException
	 */
	public void resumeDownload(IDownloadInfo downloadInfo, final RequestCallBack<File> callback) {
		try {
			HttpUtils http = new HttpUtils();
			http.configRequestThreadPoolSize(mMaxDownloadThread);
			HttpHandler<File> handler = http.download(downloadInfo.getDownloadUrl(), downloadInfo.getFileSavePath(), downloadInfo.isAutoResume(),
					downloadInfo.isAutoRename(), new ManagerCallBack(downloadInfo, callback));
			downloadInfo.setHandler(handler);
			downloadInfo.setState(handler.getState());
			mDbUtils.saveOrUpdate(downloadInfo);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Remove listener
	 */
	public interface RemoveListener {
		public void deleteLocal(String localFilePath);
	}

	/**
	 * Remove download from queue
	 * 
	 * @param index
	 * @throws DbException
	 */
	public void removeDownload(int index, RemoveListener removeL) throws DbException {
		IDownloadInfo downloadInfo = mListDownloadInfos.get(index);
		removeDownload(downloadInfo, removeL);
	}

	/**
	 * Remove download from queue
	 * 
	 * @param downloadInfo
	 * @throws DbException
	 */
	public void removeDownload(IDownloadInfo downloadInfo, RemoveListener removeL) {
		try {
			HttpHandler<File> handler = downloadInfo.getHandler();
			if (handler != null && !handler.isCancelled()) {
				handler.cancel();
			}
			mListDownloadInfos.remove(downloadInfo);
			mDbUtils.delete(downloadInfo);

			//
			removeL.deleteLocal(downloadInfo.getFileSavePath());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Remove all files
	 * 
	 * @param delFlag
	 *            : 1 Remove all success
	 *            <p>
	 *            2 Remove all not success
	 *            <p>
	 *            3 Remove All
	 */
	public void removeAllQueue(int delFlag, RemoveListener removeL) {
		//
		if (mListDownloadInfos == null || mListDownloadInfos.size() == 0) {
			return;
		}

		//
		Iterator<IDownloadInfo> it = mListDownloadInfos.iterator();
		if (it == null) {
			return;
		}

		int idx = 0;
		while (it.hasNext()) {

			Logs.i("removeAllQueue", "---idx---" + (idx++));

			//
			IDownloadInfo iDownloadInfo = it.next();

			//
			boolean isDelThis = false;

			if (delFlag == 1) {
				if (iDownloadInfo.getState() == HttpHandler.State.SUCCESS) {
					isDelThis = true;
				}

				//
			} else if (delFlag == 2) {
				if (!(iDownloadInfo.getState() == HttpHandler.State.SUCCESS)) {
					isDelThis = true;
				}

				//
			} else if (delFlag == 3) {
				isDelThis = true;
			}

			if (isDelThis) {
				try {
					HttpHandler<File> handler = iDownloadInfo.getHandler();
					if (handler != null && !handler.isCancelled()) {
						handler.cancel();
					}

					//
					it.remove();
					mDbUtils.delete(iDownloadInfo);

					//
					removeL.deleteLocal(iDownloadInfo.getFileSavePath());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * Stop the download
	 * 
	 * @param index
	 * @throws DbException
	 */
	public void stopQueue(int index) throws DbException {
		IDownloadInfo downloadInfo = mListDownloadInfos.get(index);
		stopQueue(downloadInfo);
	}

	/**
	 * Stop item Queue
	 */
	public void stopQueue(IDownloadInfo downloadInfo) throws DbException {
		// If has downloaded, just step
		if (downloadInfo == null || downloadInfo.getState() == State.SUCCESS) {
			return;
		}

		HttpHandler<File> handler = downloadInfo.getHandler();
		if (handler != null && !handler.isCancelled()) {
			handler.cancel();
		} else {
			downloadInfo.setState(HttpHandler.State.CANCELLED);
		}
		mDbUtils.saveOrUpdate(downloadInfo);
	}

	/**
	 * Stop all not success queues
	 */
	public void stopAllQueue() {

		try {
			//
			for (IDownloadInfo downloadInfo : mListDownloadInfos) {

				// If has downloaded, just step
				if (downloadInfo.getState() == State.SUCCESS) {
					continue;
				}

				//
				HttpHandler<File> handler = downloadInfo.getHandler();
				if (handler != null && !handler.isCancelled()) {
					handler.cancel();
				} else {
					downloadInfo.setState(HttpHandler.State.CANCELLED);
				}
			}

			//
			mDbUtils.saveOrUpdateAll(mListDownloadInfos);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Backup download threads
	 * 
	 * @throws DbException
	 */
	public void backupDownloadInfoList() throws DbException {
		for (IDownloadInfo downloadInfo : mListDownloadInfos) {
			HttpHandler<File> handler = downloadInfo.getHandler();
			if (handler != null) {
				downloadInfo.setState(handler.getState());
			}
		}
		mDbUtils.saveOrUpdateAll(mListDownloadInfos);
	}

	/**
	 * Manage download callback
	 */
	public class ManagerCallBack extends RequestCallBack<File> {
		private IDownloadInfo downloadInfo;
		private RequestCallBack<File> baseCallBack;

		public RequestCallBack<File> getBaseCallBack() {
			return baseCallBack;
		}

		public void setBaseCallBack(RequestCallBack<File> baseCallBack) {
			this.baseCallBack = baseCallBack;
		}

		private ManagerCallBack(IDownloadInfo downloadInfo, RequestCallBack<File> baseCallBack) {
			this.baseCallBack = baseCallBack;
			this.downloadInfo = downloadInfo;
		}

		@Override
		public Object getUserTag() {
			if (baseCallBack == null)
				return null;
			return baseCallBack.getUserTag();
		}

		@Override
		public void setUserTag(Object userTag) {
			if (baseCallBack == null)
				return;
			baseCallBack.setUserTag(userTag);
		}

		@Override
		public void onStart() {
			HttpHandler<File> handler = downloadInfo.getHandler();
			if (handler != null) {
				downloadInfo.setState(handler.getState());
			}
			try {
				mDbUtils.saveOrUpdate(downloadInfo);
			} catch (DbException e) {
				LogUtils.e(e.getMessage(), e);
			}
			if (baseCallBack != null) {
				baseCallBack.onStart();
			}
		}

		@Override
		public void onCancelled() {
			HttpHandler<File> handler = downloadInfo.getHandler();
			if (handler != null) {
				downloadInfo.setState(handler.getState());
			}
			try {
				mDbUtils.saveOrUpdate(downloadInfo);
			} catch (DbException e) {
				LogUtils.e(e.getMessage(), e);
			}
			if (baseCallBack != null) {
				baseCallBack.onCancelled();
			}
		}

		@Override
		public void onLoading(long total, long current, boolean isUploading) {
			HttpHandler<File> handler = downloadInfo.getHandler();
			if (handler != null) {
				downloadInfo.setState(handler.getState());
			}
			downloadInfo.setFileLength(total);
			downloadInfo.setProgress(current);
			try {
				mDbUtils.saveOrUpdate(downloadInfo);
			} catch (DbException e) {
				LogUtils.e(e.getMessage(), e);
			}
			if (baseCallBack != null) {
				baseCallBack.onLoading(total, current, isUploading);
			}
		}

		@Override
		public void onSuccess(ResponseInfo<File> responseInfo) {
			HttpHandler<File> handler = downloadInfo.getHandler();
			if (handler != null) {
				downloadInfo.setState(handler.getState());
			}
			try {
				mDbUtils.saveOrUpdate(downloadInfo);
			} catch (DbException e) {
				LogUtils.e(e.getMessage(), e);
			}
			if (baseCallBack != null) {
				baseCallBack.onSuccess(responseInfo);
			}
		}

		@Override
		public void onFailure(HttpException error, String msg) {
			HttpHandler<File> handler = downloadInfo.getHandler();
			if (handler != null) {
				downloadInfo.setState(handler.getState());
			}
			try {
				mDbUtils.saveOrUpdate(downloadInfo);
			} catch (DbException e) {
				LogUtils.e(e.getMessage(), e);
			}
			if (baseCallBack != null) {
				baseCallBack.onFailure(error, msg);
			}
		}
	}

	/**
	 * HTTP status handler
	 */
	private class HttpHandlerStateConverter implements ColumnConverter<HttpHandler.State> {

		@Override
		public HttpHandler.State getFieldValue(Cursor cursor, int index) {
			return HttpHandler.State.valueOf(cursor.getInt(index));
		}

		@Override
		public HttpHandler.State getFieldValue(String fieldStringValue) {
			if (fieldStringValue == null)
				return null;
			return HttpHandler.State.valueOf(fieldStringValue);
		}

		@Override
		public Object fieldValue2ColumnValue(HttpHandler.State fieldValue) {
			return fieldValue.value();
		}

		@Override
		public ColumnDbType getColumnDbType() {
			return ColumnDbType.INTEGER;
		}
	}

	/**
	 * Get download count
	 */
	public int getDownloadInfoListCount() {
		if (mListDownloadInfos == null) {
			return 0;
		}

		return mListDownloadInfos.size();
	}

	/**
	 * Get the index position download Entity
	 */
	public IDownloadInfo getDownloadInfo(int index) {
		if (mListDownloadInfos == null || index >= mListDownloadInfos.size()) {
			return null;
		}

		return mListDownloadInfos.get(index);
	}

	/**
	 * Get the download entity
	 */
	public IDownloadInfo getDownloadInfo(int parentType, long parentID, String downloadUrl) {

		IDownloadInfo downloadInfo = null;

		if (mListDownloadInfos != null) {
			for (IDownloadInfo tempInfo : mListDownloadInfos) {

				if (tempInfo.getParentType() == parentType && tempInfo.getParentID() == parentID
						&& TextUtils.equals(tempInfo.getDownloadUrl(), downloadUrl)) {
					downloadInfo = tempInfo;
					break;
				}
			}
		}

		return downloadInfo;
	}

	/**
	 * Get exist started download queue
	 * 
	 * key : file store path ,like "d://a.jpg"
	 */
	public Map<String, IDownloadInfo> getMapStartedQueue() {
		HashMap<String, IDownloadInfo> mapStoreQueue = new HashMap<String, IDownloadInfo>();

		if (mListDownloadInfos != null) {
			for (IDownloadInfo tempInfo : mListDownloadInfos) {
				mapStoreQueue.put(tempInfo.getFileSavePath(), tempInfo);
			}
		}

		return mapStoreQueue;
	}

	/**
	 * Get max download thread number
	 */
	public int getMaxDownloadThread() {
		return mMaxDownloadThread;
	}

	/**
	 * Set max download thread number
	 */
	public void setMaxDownloadThread(int maxDownloadThread) {
		this.mMaxDownloadThread = maxDownloadThread;
	}
}
