package com.lib.download;

import java.io.File;
import java.io.Serializable;

import com.lidroid.xutils.db.annotation.Transient;
import com.lidroid.xutils.http.HttpHandler;

/**
 * Download information
 * 
 * @author Jun.Wang
 */
public class IDownloadInfo implements Serializable {

	/**
	 * Serialization
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * ID
	 */
	private long id;

	/**
	 * FileName
	 * <p>
	 * Set when add new
	 */
	private String fileName = "";

	/**
	 * DownloadUrl
	 * <p>
	 * Set when add new
	 */
	private String downloadUrl = "";

	/**
	 * Total file size
	 * 
	 * M
	 */
	private double fileMLen;

	/**
	 * Download file Save Path
	 * <p>
	 * Set when add new
	 */
	private String fileSavePath = "";

	/**
	 * File LOGO URL
	 * <p>
	 * Set when add new
	 */
	private String fileLogoUrl = "";

	/**
	 * File parent ID
	 * <p>
	 * Set when add new
	 */
	private long parentID;

	/**
	 * File parent Name
	 * <p>
	 * Set when add new
	 */
	private String parentName = "";

	/**
	 * Parent LOGO URL
	 * <p>
	 * Set when add new
	 */
	private String parentLogoUrl = "";

	/**
	 * File parent type
	 * <p>
	 * Set when add new
	 */
	private int parentType;

	/**
	 * (1)If target file exist,continue download (2)If server not support range,
	 * resume download
	 * <p>
	 * Set when add new
	 */
	private boolean autoResume;

	/**
	 * If get file name from request information, rename after download
	 * finished?
	 * <p>
	 * Set when add new
	 */
	private boolean autoRename;

	/**
	 * Download progress
	 */
	private long progress;

	/**
	 * Total file size
	 * 
	 * Byte
	 */
	private long fileLength;

	@Transient
	private HttpHandler<File> handler;

	private HttpHandler.State state;

	/**
	 * Constructor
	 */
	public IDownloadInfo() {
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getDownloadUrl() {
		return downloadUrl;
	}

	public void setDownloadUrl(String downloadUrl) {
		this.downloadUrl = downloadUrl;
	}

	public void setFileMLen(double fileMLen) {
		this.fileMLen = fileMLen;
	}

	public double getFileMLen() {
		return fileMLen;
	}

	public String getFileSavePath() {
		return fileSavePath;
	}

	public void setFileSavePath(String fileSavePath) {
		this.fileSavePath = fileSavePath;
	}

	public void setFileLogoUrl(String fileLogoUrl) {
		this.fileLogoUrl = fileLogoUrl;
	}

	public String getFileLogoUrl() {
		return fileLogoUrl;
	}

	public void setParentID(long parentID) {
		this.parentID = parentID;
	}

	public long getParentID() {
		return parentID;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentType(int parentType) {
		this.parentType = parentType;
	}

	public int getParentType() {
		return parentType;
	}

	public void setParentLogoUrl(String parentLogoUrl) {
		this.parentLogoUrl = parentLogoUrl;
	}

	public String getParentLogoUrl() {
		return parentLogoUrl;
	}

	public void setAutoResume(boolean autoResume) {
		this.autoResume = autoResume;
	}

	public boolean isAutoResume() {
		return autoResume;
	}

	public void setAutoRename(boolean autoRename) {
		this.autoRename = autoRename;
	}

	public boolean isAutoRename() {
		return autoRename;
	}

	public void setProgress(long progress) {
		this.progress = progress;
	}

	public long getProgress() {
		return progress;
	}

	public void setFileLength(long fileLength) {
		this.fileLength = fileLength;
	}

	public long getFileLength() {
		return fileLength;
	}

	public HttpHandler<File> getHandler() {
		return handler;
	}

	public void setHandler(HttpHandler<File> handler) {
		this.handler = handler;
	}

	public HttpHandler.State getState() {
		return state;
	}

	public void setState(HttpHandler.State state) {
		this.state = state;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof IDownloadInfo))
			return false;

		IDownloadInfo that = (IDownloadInfo) o;

		if (id != that.id)
			return false;

		return true;
	}

	@Override
	public int hashCode() {
		return (int) (id ^ (id >>> 32));
	}
}
