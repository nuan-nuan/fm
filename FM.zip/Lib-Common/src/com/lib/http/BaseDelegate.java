package com.lib.http;

/**
 * 回调监听
 * 
 * @author Jun.Wang
 */
public interface BaseDelegate {

	/**
	 * 回调
	 */
	public void callback(IResponse response);
}
